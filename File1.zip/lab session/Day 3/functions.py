list1 = [1,2,3,4,5,6]
def sum(list1):
    total = 0
    for i in range (len(list1)):
        total += list1[i]
    return total
print(sum(list1))

def max1(a, b, c):
    return max(a, b, c)
print(max1(1,2,3))