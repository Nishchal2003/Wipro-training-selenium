nums = iter(range(1, 6))

for n in nums:
    print(n)
