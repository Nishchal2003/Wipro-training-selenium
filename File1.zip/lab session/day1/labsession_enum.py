list(enumerate(['a', 'b', 'c']))
colors = ['red', 'green', 'blue']
for i, v in enumerate(colors, start=1):
    print(i,colors)