class Employee:
    def login(self):
        print("Employee is logged in")

class Developer(Employee):
    def write_code(self):
        print("Writting code")

class tester(Employee):
    def test_code(self):
        print("Test the code")
d = Developer()
t = tester()

d.login()
d.write_code()
t.login()
t.test_code()