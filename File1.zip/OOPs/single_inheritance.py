class Employee:
    def __init__(self, name, empid):
        self.name = name
        self.empid = empid

    def empdetails(self):
        print(self.name,self.empid)

class Manager(Employee):
    def approve_leve(self):
        print("Leave approved")

m = Manager("Nishchal",21)
m.empdetails() #parent class
m.approve_leve() #child class:

