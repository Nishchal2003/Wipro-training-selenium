# Destructors - When we want to destruct an object
#post conditions - closing browser, db connection close, releasing of certain resources
# Clean up resources
# Free memory(Garbage collection)
# For proper memory usage destructors should be used
# When database connection to be closed -

class Destructor:
    def __init__(self):
        print("Object created")

    def __del__(self):
        print("Closing the db connection")

d = Destructor()
print("End of the program")
del d
class Filehandler:
    def __init__(self, filename):
        self.file = open(filename, 'w')
        print("File is opened")

    def readfile(self,filename):
        print("Reading the file")

    def __del__(self):
        self.file.close()
        print("File closed")

f = Filehandler("test.txt")
f.readfile("text.txt")
del f