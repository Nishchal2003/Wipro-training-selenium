class Calculator:
    def add(self, a, b):
        print(a + b)
c = Calculator()
c.add(10,20)
c.add(5, 7)

class Test:
    def run(self, browser = "chrome"):
        print("Running on ", browser)
t = Test()
t.run()
t.run("Firefox")

