import json

# Read JSON
with open(r"C:\Users\Nikhil\PycharmProjects\PythonProject\Data formats\employee.json", "r") as file:
    data = json.load(file)

print(data)

with open(r"C:\Users\Nikhil\PycharmProjects\PythonProject\Data formats\employee.json", "w") as file:
    json.dump(data, file, indent=4)
