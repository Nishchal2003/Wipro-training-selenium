import xml.etree.ElementTree as ET


tree = ET.parse(r"C:\Users\Nikhil\PycharmProjects\PythonProject\Data formats\employee.xml")
root = tree.getroot()
print(root.tag)

for emp in root.findall("employee"):
    if emp.get("id") == "101":
        for child in emp:
            print(child.text)


#Create the child nodes
tree = ET.parse(r"C:\Users\Nikhil\PycharmProjects\PythonProject\Data formats\employee.xml")
#create root element
root = ET.Element("employees")

emp1 = ET.SubElement(root, "employee", id = "101")
ET.SubElement(emp1, "Name").text = "Nishchal"
ET.SubElement(emp1, "Role").text = "Developer"
ET.SubElement(emp1, "Experience").text = "3"

emp2 = ET.SubElement(root, "employee", id = "102")
ET.SubElement(emp2, "Name").text = "Abhi"
ET.SubElement(emp2, "Role").text = "Tester"
ET.SubElement(emp2, "Experience").text = "2"

tree = ET.ElementTree(root)
tree.write(r"C:\Users\Nikhil\PycharmProjects\PythonProject\Data formats\write.xml")

#Updating the XML
tree = ET.parse(r"C:\Users\Nikhil\PycharmProjects\PythonProject\Data formats\employee.xml")
root = tree.getroot()

for emp in root.findall("employee"):
    if emp.get("id") == "101":
        emp.find("experience").text = "16"
ET.indent(tree, space="    ")
tree.write(r"C:\Users\Nikhil\PycharmProjects\PythonProject\Data formats\write.xml",encoding="utf-8", xml_declaration=True)