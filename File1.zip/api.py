import  requests
try:

    data = {
        "category": "Platform",
        "name": "Nishchal",
        "rating": "Mature",
        "releaseDate": "2012-05-04",
        "reviewScore": 85
    }
    response = requests.post("https://videogamedb.uk:443/api/v2/videogame/1",json = data)
    print(response)

    if response.status_code == 200:
        print("Status code is 200 k")
        #parse the json file
        data = response.json()
        print(data)
    else:
        print(f"Error Recived status code{response.status_code}")
except requests.exceptions.RequestException as e:
    print("An error occured: {e}")