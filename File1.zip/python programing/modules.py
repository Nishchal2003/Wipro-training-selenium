import math
print(math.pi)

from datetime import datetime, date
print(datetime.now())
print(date.today())

import calculator
print(calculator.add(5,5))