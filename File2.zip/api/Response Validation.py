import requests
try:
    response = requests.get("https://api.restful-api.dev/objects")
    print(response)

    if response.status_code == 200:
        print("Status code is 200 k")
        #parse data
        data = response.json()
        print(data)
        #parse the json file
        data = response.json()
        #text of the rsponse file
        print(response.text)
        #content of the response file
        print(response.content)
        #status code of the response
        print(response.status_code)
        #headers
        print(response.headers)
        #History
        print(response.history)
        #URL
        print(response.url)
        #Fetch the single header
        content_type = response.headers.get('content-Type')
        print(content_type)

    else:
        print("Error : Occured")
except requests.exceptions.RequestException as e:
    print(f"An error occured: {e}")