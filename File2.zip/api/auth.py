import requests

from requests.auth import HTTPBasicAuth
headers = {
    "User-Agent": "MyApp/1.0",
    "Accept": "application/json"
}
try:
    response = requests.get("https://api.restful-api.dev/objects",auth=HTTPBasicAuth('username', 'password'),timeout= 5,headers= headers)
    print(response)

    if response.status_code == 200:
        print("Status code is 200 k")
        #parse data
        data = response.json()
        print(data)

    else:
        print("Error : Occured")
except requests.exceptions.RequestException as e:
    print(f"An error occured: {e}")